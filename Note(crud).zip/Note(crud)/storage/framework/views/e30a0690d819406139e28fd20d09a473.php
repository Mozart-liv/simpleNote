<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-6 offset-3 mt-5">
                <a href="<?php echo e(route('post#create')); ?>" class="text-decoration-none  text-dark my-3"><i class="fa-solid fa-arrow-left me-3 text-dark"></i>back</a>
                
                <?php if(session('update')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong><?php echo e(session('update')); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="my-3">
                    <div class="d-flex justify-content-between mb-2">
                        <h3><?php echo e($data->title); ?></h3>
                        <small class="text-muted "><?php echo e($data->created_at->format('d-m-Y')); ?></small>
                    </div>
                    <p class="my-3"><?php echo e($data->description); ?></p>
                </div>

                <div class="text-end my-5">
                    <a href="<?php echo e(route('post#edit' , $data->id)); ?>" class="text-decoration-none btn btn-outline-dark px-4">Edit</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mozart/Documents/Code-lab/Note(crud)/resources/views/detail.blade.php ENDPATH**/ ?>