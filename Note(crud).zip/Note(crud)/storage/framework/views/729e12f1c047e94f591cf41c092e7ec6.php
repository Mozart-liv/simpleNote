<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-6 offset-3 mt-5">
            <a href="<?php echo e(route('post#detail', $data->id)); ?>" class="text-decoration-none  text-dark"><i class="fa-solid fa-arrow-left me-3 text-dark"></i>back</a>
            <form action="<?php echo e(route('post#update', $data->id)); ?>" method="post">
                <div class="text-group my-3">
                    <label for="">Note Title</label>
                    <input type="text" name="title" class="form-control my-3" value="<?php echo e($data->title); ?>">
                </div>

                <div class="text-group">
                    <label for="">Note Description</label>
                    <textarea name="description" class="form-control my-3 p-3" cols="30" rows="40"><?php echo e($data->description); ?></textarea>
                </div>
            </form>

            <div class="text-end ">
                    <a href="<?php echo e(route('post#update' , $data->id)); ?>" class="text-decoration-none btn btn-outline-info px-4">Save</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mozart/Documents/Code-lab/Note(crud)/resources/views/update.blade.php ENDPATH**/ ?>