@extends('main')

@section('content')
    <div class="container">
        <div class="col-6 offset-3 mt-5">
            <a href="{{ route('post#detail',$data->id) }}" class="text-decoration-none  text-dark"><i class="fa-solid fa-arrow-left me-3 text-dark"></i>back</a>
            <form action="{{route('post#update', $data->id)}}" method="post">
                @csrf
                <div class="text-group my-3">
                    <label for="">Note Title</label>
                    <input type="text" name="title" class="form-control my-3 @error('title') is-invalid @enderror" value="{{old('title', $data->title)}}">
                    @error('title')
                        <div class="invalid-feedback">
                            {{$message}}
                        </div>
                     @enderror
                </div>

                <div class="text-group">
                    <label for="">Note Description</label>
                    <textarea name="description" class="form-control my-3 p-3 @error('description') is-invalid @enderror" cols="30" rows="10">{{old('description', $data->description)}}</textarea>
                    @error('description')
                        <div class="invalid-feedback">
                            {{$message}}
                        </div>
                     @enderror
                </div>

                <div class="text-end ">
                    <input type="submit" class="btn btn-outline-info px-3" value="Save">
                </div>
            </form>

            
        </div>
    </div>
@endsection
