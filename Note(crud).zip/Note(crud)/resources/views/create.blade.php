@extends('main')

@section('content')
    <div class="container">
        <div class="row mt-5">
            <div class="col-4 position-fixed">
                
                @if (session('insert'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>{{session('insert')}}</strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
                
                <div class="p-3">
                    <form action="{{ route('post#insert')}}" method="post">
                        @csrf
                        <div class="text-group mb-3">
                            <label for="" class="form-label">Note Title</label>
                            <input type="text" name="title" class="form-control @error('title') is-invalid @enderror" placeholder="Enter Title..." value="{{old('title')}}">
                            @error('title')
                                <div class="invalid-feedback">
                                    {{$message}}
                                </div>
                            @enderror
                        </div>
                        <div class="text-group mb-3">
                            <label for="" class="form-label">Note description</label>
                            <textarea name="description" id="" cols="30" rows="10" class="form-control @error('description') is-invalid @enderror" placeholder="Enter Your mind...">{{old('description')}}</textarea>
                            @error('description')
                                <div class="invalid-feedback">
                                    {{$message}}
                                </div>
                            @enderror
                        </div>
                        <div class="">
                            <input type="submit" value="Save" class="btn btn-danger px-5">
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-7 offset-5">
                <h1>Total - {{$data->total()}}</h1>

                @if (session('delete'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>{{session('delete')}}</strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
                <div class="data-con my-4">
                    @foreach ($data as $item)
                        <div class="post shadow-sm p-3 mb-3 border border-dark rounded">
                            <div class="d-flex justify-content-between mb-2">
                                <h4>{{$item->title}}</h4>
                                <small class="text-muted">{{$item->created_at->format('d-m-Y')}}</small>
                            </div>
                            <p>{{Str::words($item->description, 15 , '')}} <a href="{{route('post#detail' , $item->id)}}" class="text-decoration-none "><small>See more ...</small></a> </p>
                            <div class="text-end">
                                <a href="{{ route('post#delete' , $item->id) }}" class="btn btn-outline-danger mx-2 px-4">
                                    <i class="fa-solid fa-trash me-3"></i>Delete
                                </a>
                                            
                            </div>
                        </div>
                    @endforeach
                </div>
                {{$data->links()}}
            </div>
        </div>
    </div>
@endsection