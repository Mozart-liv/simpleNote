@extends('main')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-6 offset-3 mt-5">
                <a href="{{ route('post#create') }}" class="text-decoration-none  text-dark my-3"><i class="fa-solid fa-arrow-left me-3 text-dark"></i>back</a>
                
                @if (session('update'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>{{session('update')}}</strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                <div class="my-3">
                    <div class="d-flex justify-content-between mb-2">
                        <h3>{{$data->title}}</h3>
                        <small class="text-muted ">{{$data->created_at->format('d-m-Y')}}</small>
                    </div>
                    <p class="my-3">{{$data->description}}</p>
                </div>

                <div class="text-end my-5">
                    <a href="{{route('post#edit' , $data->id)}}" class="text-decoration-none btn btn-outline-dark px-4">Edit</a>
                </div>
            </div>
        </div>
    </div>
@endsection