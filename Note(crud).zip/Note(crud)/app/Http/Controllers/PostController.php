<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PostController extends Controller
{
    public function create(){

        $data = Post::orderBy('created_at', 'desc')->paginate(3);
        return view('create', compact('data'));
        
    }


    //insert data
    public function insert(Request $request){
        $this->Valcheck($request);

        $data = $this->getData($request);
        Post::create($data);
        return back()->with(['insert'=>'Sucessfully Created']);

    }

    //delete data
    public function delete($id){
        Post::where('id',$id)->delete();

        //sec way
        //Post::find($id)->delete();
        return back()->with(['delete'=>'Sucessfully Deleted']);
    }

    // show data
    public function detail($id){
        $data = Post::where('id',$id)->first();
        return view('detail', compact('data'));
    }

    //edit data
    public function edit($id){
        $data = Post::where('id',$id)->first();
        return view('edit', compact('data'));
    }

    //update data
    public function update(Request $request, $id){
        $this->Valcheck($request);
        $update = $this->getData($request);
        Post::where('id', $id)->update($update);
        return redirect()->route('post#detail', ['id' => $id])->with(['update'=>'Sucessfully Updated']);
    }
    //validation 
    public function Valcheck($request){
        $valMessage=[
            'title.required' => 'Fill title pls',
            'description.required' => 'Fill description pls',
            'title.unique' => 'Why do you fill same name again?'
        ];

        Validator::make($request->all(),[
            'title' => 'required|unique:posts,title,'.$request->id,
            'description' => 'required'
        ],$valMessage)->validate();
    }

    //get data function
    private function getData($request){
        return [
            'title' => $request->title,
            'description' => $request->description
        ];
    }
}
